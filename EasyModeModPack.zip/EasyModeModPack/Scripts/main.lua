local config = require("config")
print("Loaded Config File")
print("Loaded Midsubspace's Mod Pack Version Alpha 0.2.5")
if config.InfiniteBunPack then
  print("InfiniteBunPack is enabled")
  require("mods/InfiniteBunPack/main")
end
if config.SelfRefillingOilCan then
  print("SelfRefillingOilCan is enabled")
  require("mods/SelfRefillingOilCan/main")
end
if config.UnlimitedWrapperBoxes then
  print("UnlimitedWrapperBoxes is enabled")
  require("mods/UnlimitedWrapperBoxes/main")
end
if config.InfiniteDriveThruBags then
  print("InfiniteDriveThruBags is enabled")
  require("mods/InfiniteDriveThruBags/main")
end
if config.FryerDonenessFreeze then
  print("FryerDonenessFreeze is enabled")
  require("mods/FryerDonenessFreeze/main")
end
if config.PattyDonenessFreeze then
  print("PattyDonenessFreeze is enabled")
  require("mods/PattyDonenessFreeze/main")
end
if config.InfiniteSauceSupply then
  print("InfiniteSauceSupply is enabled")
  require("mods/InfiniteSauceSupply/main")
end
if config.EndlessSodaCups then
  print("EndlessSodaCups is enabled")
  require("mods/EndlessSodaCups/main")
end
if config.InfiniteIceCreamCups then
  print("InfiniteIceCreamCups is enabled")
  require("mods/InfiniteIceCreamCups/main")
end
if config.CustomerPatience then
  print("CustomerPatience is enabled")
  require("mods/CustomerPatience/main")
end
if config.InfiniteSmallFryBoxes then
  print("InfiniteSmallFryBoxes is enabled")
  require("mods/InfiniteSmallFryBoxes/main")
end
if config.InfiniteMedFryBoxes then
  print("InfiniteMedFryBoxes is enabled")
  require("mods/InfiniteMedFryBoxes/main")
end
if config.InfiniteLargeFryBoxes then
  print("InfiniteLargeFryBoxes is enabled")
  require("mods/InfiniteLargeFryBoxes/main")
end
if config.UnlimitedCrates then
  print("UnlimitedCrates is enabled")
  require("mods/UnlimitedCrates/main")
end
if config.EndlessPickles then
  print("EndlessPickles is enabled")
  require("mods/EndlessPickles/main")
end
if config.OilContaminationPrevention then
  print("OilContaminationPrevention is enabled")
  require("mods/OilContaminationPrevention/main")
end
if config.InfinitePattyBox then
  print("InfinitePattyBox is enabled")
  require("mods/InfinitePattyBox/main")
end
if config.InfiniteFriesAndNuggetsBox then
  print("InfiniteFriesAndNuggetsBox is enabled")
  require("mods/InfiniteFriesAndNuggetsBox/main")
end
if config.DriveThruPatience then
  print("DriveThruPatience is enabled")
  require("mods/DriveThruPatience/main")
end
if config.InfiniteCoffeeCups then
  print("InfiniteCoffeeCups is enabled")
  require("mods/InfiniteCoffeeCups/main")
end
if config.TempFreezer then
  print("TempFreezer is enabled")
  require("mods/TempFreezer/main")
end
if config.InfiniteCheeseBox then
  print("InfiniteCheeseBox is enabled")
  require("mods/InfiniteCheeseBox/main")
end
if config.InfiniteCoffeeBox then
  print("InfiniteCoffeeBox is enabled")
  require("mods/InfiniteCoffeeBox/main")
end
if config.InfiniteMilkBox then
  print("InfiniteMilkBox is enabled")
  require("mods/InfiniteMilkBox/main")
end