
-- Function to find all customer components dynamically
local function findAllCustomers()
    local allCustomers = FindAllOf("BP_Customer_C") -- Get all instances of BP_Customer_C
    if allCustomers then
        --print("Found " .. #allCustomers .. " customers.")
        return allCustomers
    else
        --print("No customers found.")
        return nil
    end
end

-- Function to set the patience for all customers
local function setAllCustomersPatience(value)
    local customers = findAllCustomers()
    if customers then
        for _, customer in pairs(customers) do
            customer:SetPropertyValue("Patience", value)
            customer:SetPropertyValue("UpdatePatienceTime",300)
            
            --print("Set Patience to " .. value .. " for customer: " .. customer:GetFullName())
        end
    end
end
-- Function to toggle the patience mod on/off
local function togglePatienceMod()
        -- Start the LoopAsync to keep setting patience every 100ms
        LoopAsync(10000, function()
                setAllCustomersPatience(100.0) -- Continuously set patience to 1.0
        end)
end

    togglePatienceMod()
    print("Loaded CustomerPatience Mod- Thanks b3ck")