local FriesBox_States = {}

local function findAll_FriesBox()
    local findAll_FriesBox = FindAllOf("BP_FriesNuggetsBox_C")
    if findAll_FriesBox then
        --print("Found " .. #findAll_FriesBox .. "  FriesBox Packs.")
        return findAll_FriesBox
    else
        --print("Found No FriesBox Packs")
        return nil
    end
end

local function extractID(FriesBox)
    local fullName = FriesBox:GetFullName()
    local FriesBox_ID = fullName:match("BP_FriesNuggetsBox_C_([%d]+)$")
    --print("Extracted Bun Pack ID: " .. tostring(FriesBox_ID))
    return FriesBox_ID
end

local function check_FriesBox_StackCount()
    local FriesBox_s = findAll_FriesBox()
    if FriesBox_s then
        for _, FriesBox in pairs(FriesBox_s) do
            local FriesBox_ID = extractID(FriesBox)
            if FriesBox_ID then
                local currentPackCount = FriesBox:GetPropertyValue("ItemStackCount")
                local SauceType = FriesBox:GetPropertyValue("ItemStackCount")
                --print("Info ID: " .. FriesBox_ID .. "Current_count:" .. currentPackCount)
                local lastPackCount = FriesBox_States[FriesBox_ID] or 0
                if currentPackCount <=1 then
                    FriesBox:SetPropertyValue("ItemStackCount",4)
                end
                FriesBox_States[FriesBox_ID] = currentPackCount
            end
        end
    end
end
LoopAsync(100, function()
    check_FriesBox_StackCount()
    return false
end)

print("Loaded Infinite Fries Box")