return {
	InfiniteBunPack = false,	-- This mod ensures that you always have a supply of buns, eliminating the need to constantly restock.
	SelfRefillingOilCan = false, -- This mod automatically empites the oil can when it gets full, eliminating the need to empty it out back. ( Not Needed if using OilContaminationPrevention)
	UnlimitedWrapperBoxes = false, -- This mod provides an endless supply of burger wrappers, eliminating the need to purchase more.
	FryerDonenessFreeze = false, -- This mod freezes the doneness of items in the fryer once they reach 100%, preventing them from overcooking. However, you still need to remove them to prevent the oil from going bad if your not using OilContaminationPrevention
	PattyDonenessFreeze = false, -- This mod freezes the doneness of patties once they reach 100%, preventing them from overcooking. However, you still need to flip them to ensure both sides cook evenly.
	InfiniteSauceSupply = false, -- This mod ensures that you always have a supply of sauce bottles, eliminating the need to refill them. Need to fill them full one time
	EndlessSodaCups = false, -- This mod provides an endless stack of soda cups, eliminating the need to purchase more.
	InfiniteIceCreamCups = false, -- This mod ensures that you always have a stack of ice cream cups, eliminating the need to purchase more than one
	CustomerPatience = false, -- This mod ensures that customers have infinite patience, preventing them from leaving due to long wait times.
	DriveThruPatience = false, -- This mod ensures that Drive Thru customers have infinite patience, preventing them from leaving due to long wait times.
	InfiniteSmallFryBoxes = false, -- This mod provides an endless supply of Small fry scoops , eliminating the need to purchase more than one
	InfiniteMedFryBoxes = false, -- This mod provides an endless supply of Medium fry scoops , eliminating the need to purchase more than one
	InfiniteLargeFryBoxes = false, -- This mod provides an endless supply of Large fry scoops , eliminating the need to purchase more than one
	InfiniteDriveThruBags = false, -- This mod provides an endless supply of Drive Thur Bags , eliminating the need to purchase more than one
	UnlimitedCrates = false, -- This mod provides an endless supply of crates for Lettuce and Tomato, eliminating the need to purchase more than one
	EndlessPickles = false, -- This mod ensures that you always have a supply of pickle jar, eliminating the need to restock.
	OilContaminationPrevention = false, -- This mod prevents oil contamination in the fryer, ensuring that the oil remains clean and usable for longer.
	InfinitePattyBox = false, -- This mod provies an endless supply of patties, eliminating the need to purchase more than one box of patties
	InfiniteFriesAndNuggetsBox = false, -- This mod provies an endless supply of Fries, eliminating the need to purchase more than one box of Fries
	InfiniteCoffeeCups = false, -- This mod ensures that you always have a stack of Coffee  cups, eliminating the need to purchase more than one
	TempFreezer = false, -- This mod ensures that your food and drinks remain at the perfect temp.
	InfiniteCheeseBox = false, -- This mod provies an endless supply of Cheese, eliminating the need to purchase more than one box of Cheese
	InfiniteCoffeeBox = false, -- This mod provies an endless supply of Coffee, eliminating the need to purchase more than one box of Coffee
	InfiniteMilkBox = false -- This mod provies an endless supply of Milk, eliminating the need to purchase more than one box of Milk
}